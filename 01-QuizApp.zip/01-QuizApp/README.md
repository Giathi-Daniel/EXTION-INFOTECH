# React + Vite

*Quiz App* designed in REACT and Material UI