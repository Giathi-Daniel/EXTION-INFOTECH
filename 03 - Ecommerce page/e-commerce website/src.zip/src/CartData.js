export const cartItems = [
    {
      id: 1,
      imgSrc: "https://m.media-amazon.com/images/I/71lI0RJAInL._AC_UY327_FMwebp_QL65_.jpg",
      name: "Large Print Backlit Keyboard",
      price: 28.99,
      quantity: 1,
    },
    {
      id: 2,
      imgSrc: "https://m.media-amazon.com/images/I/61P9FlT2gCL._AC_UY327_FMwebp_QL65_.jpg",
      name: "GEEKERA 3 in 1 Wireless Charging Station",
      price: 35.99,
      quantity: 2,
    },
  ];
  